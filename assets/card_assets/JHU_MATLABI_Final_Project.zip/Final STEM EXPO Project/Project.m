% Final EXPO STEM Project
% November 29 2021
% Sai Siddhish Chandra Sekaran
clear, clc
%% Tests

% Test #1: Math
MathScoreNum = 0;

MathQuestions = {'What is 20+25? ', 'What is 34-5? ', 'What is 12*5? ', 'What is 100/10? ', 'What is the square root of -64? ', 'What is 15 squared? '};
MathAnswers = {'45', '29', '60', '10', '8i', '225'};

for i = 1:length(MathQuestions)
    MathQAnswer = input(MathQuestions{i}, 's');
    if strcmpi(MathQAnswer, MathAnswers{i})
        MathScoreNum = MathScoreNum + 1;
    end
end

% Test 2: Science
SciScoreNum = 0;

SciQuestions = {'What human body part, pumps blood? (Put just the organ namne, no ''the'' infront) ', 'What is the formula to calculate force? (NO SPACES) ', 'What is the 4th type of matter after solid, liquid, and gas? '};
SciAnswers = {'heart', 'f=ma', 'plasma'};

for i = 1:length(SciQuestions)
    SciQAnswer = input(SciQuestions{i}, 's');
    if strcmpi(SciQAnswer, SciAnswers{i})
        SciScoreNum = SciScoreNum + 1;
    end
end

% Test 3: Geography

GeoScoreNum = 0;

GeoQuestions = {'In what year was the Declaration of Independence signed? ', 'In what year was the American Constituton written? '};
GeoAnswers = {'1776', '1787'};

for i = 1:length(GeoQuestions)
    GeoQAnswer = input(GeoQuestions{i}, 's');
    if strcmpi(GeoQAnswer, GeoAnswers{i})
        GeoScoreNum = GeoScoreNum + 1;
    end
end

% Test 4: English

EngScoreNum = 0;

EngQuestions = {'Is the word ''red'' a noun, adjective, or verb? ', 'Is the word ''house'' a noun, adjective, or verb? '};
EngAnswers = {'adjective', 'noun'};

for i = 1:length(EngQuestions)
    EngQAnswer = input(EngQuestions{i}, 's');
    if strcmpi(EngQAnswer, EngAnswers{i})
        EngScoreNum = EngScoreNum + 1;
    end
end

% Test 5: Technology

TechScoreNum = 0;

TechQuestions = {'What does the term CPU stand for? ', 'What does the term GPU stand for? ', 'What does the term RAM stand for? ', 'What does the term SSD stand for? ', 'What does the term SATA stand for? ', 'What does the term BIOS stand for? ', 'What does the term UEFI stand for? ', 'What does the term PC stand for? ', 'What does the term Mac stand for? '};
TechAnswers = {'central processing unit', 'graphics processing unit', 'random access memory', 'solid state drive', 'serial ata', 'basic input output system', 'unified extensible firmware interface', 'personal computer', 'macintosh'};

for i = 1:length(TechQuestions)
    TechQAnswer = input(TechQuestions{i}, 's');
    if strcmpi(TechQAnswer, TechAnswers{i})
        TechScoreNum = TechScoreNum + 1;
    end
end

%% Score Counting

% Test 1
MathScore = MathScoreNum/length(MathQuestions);
MathPercentage = MathScore*100;

% Test 2
SciScore = SciScoreNum/length(SciQuestions);
SciPercentage = SciScore*100;

% Test 3
GeoScore = GeoScoreNum/length(GeoQuestions);
GeoPercentage = GeoScore*100;

% Test 4
EngScore = EngScoreNum/length(EngQuestions);
EngPercentage = EngScore*100;

% Test 5
TechScore = TechScoreNum/length(TechQuestions);
TechPercentage = TechScore*100;

%%

TestPercentages = [MathPercentage, SciPercentage, GeoPercentage, EngPercentage, TechPercentage];

if MathPercentage == 100 && SciPercentage == 100 && GeoPercentage == 100 && EngPercentage == 100 && TechPercentage == 100
    X = categorical({'Math','Science','Geography','English', 'Technology'});
    X = reordercats(X,{'Math','Science','Geography','English', 'Technology'});

    figure('Name','Test Scores Bar Graph','NumberTitle','off');
    b = bar(X, TestPercentages, 0.5);
    b.FaceColor = 'flat';
    b.CData(1,:) = [1 0 0];
    b.CData(2,:) = [0 1 0];
    b.CData(3,:) = [0 0 1];
    b.CData(4,:) = [1 1 0];
    xtips1 = b(1).XEndPoints;
    ytips1 = b(1).YEndPoints;
    labels1 = string(b(1).YData);
    xlim = 5;
    ylim = 100;
    text(xtips1,ytips1,labels1,'HorizontalAlignment','center','VerticalAlignment','bottom');
    title('Congratulations, You scored a perfect score!');
    xlabel('Subjects');
    ylabel('Scores');

    figure('Name','Test Scores Box Plot','NumberTitle','off');
    boxchart(TestPercentages);
    title('Congratulations, You scored a perfect score!');
    ylabel('Score(s)'); 
else
    X = categorical({'Math','Science','Geography','English', 'Technology'});
    X = reordercats(X,{'Math','Science','Geography','English', 'Technology'});

    figure('Name','Test Scores Bar Graph','NumberTitle','off');
    b = bar(X, TestPercentages, 0.5);
    b.FaceColor = 'flat';
    b.CData(1,:) = [1 0 0];
    b.CData(2,:) = [0 1 0];
    b.CData(3,:) = [0 0 1];
    b.CData(4,:) = [1 1 0];
    xtips1 = b(1).XEndPoints;
    ytips1 = b(1).YEndPoints;
    labels1 = string(b(1).YData);
    xlim = 5;
    ylim = 100;
    text(xtips1,ytips1,labels1,'HorizontalAlignment','center','VerticalAlignment','bottom');
    title('Test Scores Bar Graph');
    xlabel('Subjects');
    ylabel('Scores');

    figure('Name','Test Scores Box Plot','NumberTitle','off');
    boxchart(TestPercentages);
    title('Test Scores Box Plot');
    ylabel('Score(s)');
end