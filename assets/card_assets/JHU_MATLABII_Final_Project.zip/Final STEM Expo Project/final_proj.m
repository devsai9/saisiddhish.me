%% Import Initial Tables
smokingvslungcancer = readcell('smoking_vs_lung_cancer.csv');
smokingratesbycountry = readcell('smoking_rates_by_country.csv');
%% Change Table Values
for i = 2:length(smokingvslungcancer) 
    if smokingvslungcancer{i, 1} == 1
       smokingvslungcancer{i, 1} =  0; 
    elseif smokingvslungcancer{i, 1} == 2
       smokingvslungcancer{i, 1} =  1; 
    end
    
    if smokingvslungcancer{i, 2} == "NO"
       smokingvslungcancer{i, 2} =  0; 
    elseif smokingvslungcancer{i, 2} == "YES"
       smokingvslungcancer{i, 2} =  1; 
    end
end
%% Find Smoking to Cancer rate (smoking_vs_lung_cancer.csv)
numOfSmokersThatHaveLungCancer = 0;
numOfPeopleThatHaveLungCancer = 0;

for i = 2:length(smokingvslungcancer)
    numOfPeopleThatHaveLungCancer = numOfPeopleThatHaveLungCancer + smokingvslungcancer{i, 2};
    
    if smokingvslungcancer{i, 1} == 1 && smokingvslungcancer{i, 2} == 1
        numOfSmokersThatHaveLungCancer = numOfSmokersThatHaveLungCancer + 1;
    end
end

smokingLungCancerDecimal = (numOfSmokersThatHaveLungCancer/numOfPeopleThatHaveLungCancer);
smokingLungCancerPercentage = (numOfSmokersThatHaveLungCancer/numOfPeopleThatHaveLungCancer)*100;
%% Apply the Smoking to Cancer rate to top 5 smoking countries (smoking_rates_by_country.csv)

smokingRateForNauru = smokingratesbycountry{2, 2};
smokingRateForKiribati = smokingratesbycountry{3, 2};
smokingRateForTuvalu = smokingratesbycountry{4, 2};
smokingRateForMyanmar = smokingratesbycountry{5, 2};
smokingRateForChile = smokingratesbycountry{6, 2};

lungCancerRateForNauru = round(smokingRateForNauru * smokingLungCancerDecimal, 2);
lungCancerRateForKiribati = round(smokingRateForKiribati * smokingLungCancerDecimal, 2);
lungCancerRateForTuvalu = round(smokingRateForTuvalu * smokingLungCancerDecimal, 2);
lungCancerRateForMyanmar = round(smokingRateForMyanmar * smokingLungCancerDecimal, 2);
lungCancerRateForChile = round(smokingRateForChile * smokingLungCancerDecimal, 2);

%% Graphing (top 5)!

X = categorical({'Nauru','Kiribati','Tuvalu','Myanmar','Chile'});
X = reordercats(X,{'Nauru','Kiribati','Tuvalu','Myanmar','Chile'});

y = [smokingRateForNauru lungCancerRateForNauru; smokingRateForKiribati lungCancerRateForKiribati; 
    smokingRateForTuvalu lungCancerRateForTuvalu; smokingRateForMyanmar lungCancerRateForMyanmar; 
    smokingRateForChile lungCancerRateForChile];

figure;
hold on;
b = bar(X,y, 0.9);
title('Smoking and Predicted Lung Cancer Percentages for the Top 5 Smoking Countries');
legend({'Smoking Percentages','Predicted Lung Cancer Percentages'});
xlabel('Country Name');
ylabel('Percentages');

xtips1 = b(1).XEndPoints;
ytips1 = b(1).YEndPoints;
labels1 = string(b(1).YData);
text(xtips1,ytips1,labels1,'HorizontalAlignment','center','VerticalAlignment','bottom', 'FontSize', 8)

xtips2 = b(2).XEndPoints;
ytips2 = b(2).YEndPoints;
labels2 = string(b(2).YData);
text(xtips2,ytips2,labels2,'HorizontalAlignment','center','VerticalAlignment','bottom', 'FontSize', 8)

hold off;
%% Apply the Smoking to Cancer rate to 4 European Countries (smoking_rates_by_country.csv)
% Serbia
% Greece
% Bulgaria
% Bosnia and Herzegovina

smokingRateForSerbia = smokingratesbycountry{8, 2};
smokingRateForGreece = smokingratesbycountry{9, 2};
smokingRateForBulgaria = smokingratesbycountry{11, 2};
smokingRateForBosnia_and_Herzegovina = smokingratesbycountry{12, 2};

lungCancerRateForSerbia = round(smokingRateForSerbia * smokingLungCancerDecimal, 2);
lungCancerRateForGreece = round(smokingRateForGreece * smokingLungCancerDecimal, 2);
lungCancerRateForBulgaria = round(smokingRateForBulgaria * smokingLungCancerDecimal, 2);
lungCancerRateForBosnia_and_Herzegovina = round(smokingRateForBosnia_and_Herzegovina * smokingLungCancerDecimal, 2);
%% Graphing (Top 4 Europe)!

X = categorical({'Serbia','Greece','Bulgaria','Bosnia and Herzegovina'});
X = reordercats(X,{'Serbia','Greece','Bulgaria','Bosnia and Herzegovina'});

y = [smokingRateForSerbia lungCancerRateForSerbia; smokingRateForGreece lungCancerRateForGreece; 
    smokingRateForBulgaria lungCancerRateForBulgaria; smokingRateForBosnia_and_Herzegovina lungCancerRateForBosnia_and_Herzegovina];

figure;
hold on;
b = bar(X,y, 0.9);
title('Smoking and Predicted Lung Cancer Percentages for the Top 4 Smoking European Countries');
legend({'Smoking Percentages','Predicted Lung Cancer Percentages'});
xlabel('Country Name');
ylabel('Percentages');

xtips1 = b(1).XEndPoints;
ytips1 = b(1).YEndPoints;
labels1 = string(b(1).YData);
text(xtips1,ytips1,labels1,'HorizontalAlignment','center','VerticalAlignment','bottom', 'FontSize', 8)

xtips2 = b(2).XEndPoints;
ytips2 = b(2).YEndPoints;
labels2 = string(b(2).YData);
text(xtips2,ytips2,labels2,'HorizontalAlignment','center','VerticalAlignment','bottom', 'FontSize', 8)

hold off;
%% Apply the Smoking to Cancer rate to 4 Asian Countries (smoking_rates_by_country.csv)
% Myanmar
% Lebanon
% Bangladesh
% Timor-Leste

smokingRateForMyanmar = smokingratesbycountry{5, 2};
smokingRateForLebanon = smokingratesbycountry{7, 2};
smokingRateForBangladesh = smokingratesbycountry{10, 2};
smokingRateForTimor_Leste = smokingratesbycountry{13, 2};

lungCancerRateForMyanmar = round(smokingRateForMyanmar * smokingLungCancerDecimal, 2);
lungCancerRateForLebanon = round(smokingRateForLebanon * smokingLungCancerDecimal, 2);
lungCancerRateForBangladesh = round(smokingRateForBangladesh * smokingLungCancerDecimal, 2);
lungCancerRateForTimor_Leste = round(smokingRateForTimor_Leste * smokingLungCancerDecimal, 2);
%% Graphing (Top 4 Asia)!

X = categorical({'Myanmar','Lebanon','Bangladesh','Timor-Leste'});
X = reordercats(X,{'Myanmar','Lebanon','Bangladesh','Timor-Leste'});

y = [smokingRateForMyanmar lungCancerRateForMyanmar; smokingRateForLebanon lungCancerRateForLebanon; 
    smokingRateForBangladesh lungCancerRateForBangladesh; 
    smokingRateForTimor_Leste lungCancerRateForTimor_Leste];

figure;
hold on;
b = bar(X,y, 0.9);
title('Smoking and Predicted Lung Cancer Percentages for the Top 4 Smoking Asian Countries');
legend({'Smoking Percentages','Predicted Lung Cancer Percentages'});
xlabel('Country Name');
ylabel('Percentages');

xtips1 = b(1).XEndPoints;
ytips1 = b(1).YEndPoints;
labels1 = string(b(1).YData);
text(xtips1,ytips1,labels1,'HorizontalAlignment','center','VerticalAlignment','bottom', 'FontSize', 8)

xtips2 = b(2).XEndPoints;
ytips2 = b(2).YEndPoints;
labels2 = string(b(2).YData);
text(xtips2,ytips2,labels2,'HorizontalAlignment','center','VerticalAlignment','bottom', 'FontSize', 8)

hold off;